#include<iostream>
using namespace std;
int main()
{
	int password;
	bool accessgranted=false;
	
while(!accessgranted)
{
cout<<"enter password"<<endl;
cin>>password;

if(password==12345)
{
	accessgranted=true;
	cout<<"successful"<<endl;
}
else{
	cout<<"incorrect password"<<endl;
}
}
	return 0;
}
#include<iostream>
using namespace std;
int main()
{
	int n;
	int sum=0;
	int i=0;
	float average;
do
{
	cout<<"enter number"<<endl;
	cin>>n;
	sum+=n;
	i++;
}
while(n<7);
average=sum/n;
cout<<"average"<<average<<endl;

return 0;
}